<?php
// Include the header
include_once 'HEADER2.php';

// Include the main content pages
include_once 'home2.php';
include_once 'about.php';
include_once 'contact.php';
// Include the footer last
include_once 'footer.php';
